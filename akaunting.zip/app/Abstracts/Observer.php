<?php

namespace App\Abstracts;

use Akaunting\MutableObserver\Traits\Mutable;

abstract class Observer
{
    use Mutable;
}
